package days05;

import java.io.IOException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.DBConn;

public class Delete extends HttpServlet{

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("> Delete.doGet()...");

		String path = "/days05/delete.jsp";
		//response.sendRedirect(location);
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("> Delete.doPost()...");
		// 한글 깨짐 처리 : ( POST 방식 )
		request.setCharacterEncoding("UTF-8");
		//
		int seq = Integer.parseInt(  request.getParameter("seq")  ); 
		String p_password = request.getParameter("password");
		
		//
		Connection con = null;
		PreparedStatement pstmt = null;		
		int resultCnt = 0 ;
		
		try {
			// seq의 password select
			String sql = "select password "
								+ "from tbl_myboard "
								+ "where seq = ?";
			con = DBConn.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, seq);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			String o_password  = rs.getString("password");
			rs.close();
			if( !o_password.equals(p_password) ) {
				request.setAttribute("error", "비밀번호가 틀립니다.");
				doGet(request, response);
				DBConn.close();
				return;
			}
			
			//
			sql = "delete from tbl_myboard "
					+ " where seq = ?";			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, seq);
			resultCnt = pstmt.executeUpdate();
			pstmt.close();
			DBConn.close();
		} catch (Exception e) {  // 
			e.printStackTrace();
		} 
		
		// 글 목록 페이지 이동
		//     /board/list GET요청 -> List.java -> days05/list.jsp 응답
		String location="/jspPro/board/list";	 
		
		int currentPage = Integer.parseInt( request.getParameter("currentPage") );
		String searchCondition = request.getParameter("searchCondition");
		String searchWord = request.getParameter("searchWord");
		
		if( resultCnt == 1 ) {			
			location += "?delete=success";		
			location += String.format(
				"&currentPage=%d&searchCondition=%s&searchWord=%s",
				currentPage,searchCondition, searchWord );
			}
		response.sendRedirect(location);
	}

}
