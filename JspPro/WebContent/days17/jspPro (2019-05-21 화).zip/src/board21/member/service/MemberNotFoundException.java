package board21.member.service;

//  p 596
public class MemberNotFoundException extends RuntimeException{

}
