package board21.member.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import javax.naming.NamingException;

import com.util.ConnectionProvider;
import com.util.JdbcUtil;

import board21.member.dao.MemberDao;
import board21.member.model.Member;

// p 596
public class JoinService {

	private MemberDao memberDao = new MemberDao();

	public void join( JoinRequest joinReq ) {
		Connection conn = null;
		try {
			conn = ConnectionProvider.getConnection();
			conn.setAutoCommit(false);

			Member member = this.memberDao.selectById(conn, joinReq.getMemberid());

			if( member != null) {
				JdbcUtil.rollback(conn);;
				throw new DuplicatedIdException();
			}

			this.memberDao.insert(conn, new Member(
					joinReq.getMemberid()
					, joinReq.getName()
					, joinReq.getPassword()
					));
			conn.commit();
		}catch(Exception e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} finally {
			JdbcUtil.close(conn);
		}

	}

}
