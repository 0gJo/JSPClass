package board21.auth.service;

public class User {

}
