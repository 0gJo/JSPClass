package days05;

import java.io.IOException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.DBConn;

public class List extends HttpServlet{

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("> List.doGet()/doPost()...");
		// 검색 조건, 검색어  코딩 추가.
		int searchCondition = Integer.parseInt( 
				request.getParameter("searchCondition") ==null?
						  "1": request.getParameter("searchCondition") );
		
		request.setAttribute("searchCondition", searchCondition);  // 
		
		String searchWord = request.getParameter("searchWord")  ;
		request.setAttribute("searchWord", searchWord);              // 
		
		if( searchWord == null || searchWord.equals("") ) searchWord ="*"; 
		
		String pCurrentPage =  request.getParameter("currentPage");		
		int currentPage = pCurrentPage==null ? 1 : Integer.parseInt(pCurrentPage);  
		// 현재 페이지 번호
        int numberPerPage = 10;
        
		// tbl_board request.setAttribute();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<MyBoardDTO> list = null;
		
		try {
			String sql = " select *                                                     ";
		    sql+=     " from (                                                       ";
			sql+=   "     select rownum no, t.*                                    ";
			sql+=   "     from (                                                   ";
			sql+=   "         select  seq, name, email, subject, cnt, regdate      ";
			sql+=   "         from tbl_myboard                                     ";
			//  검색 쿼리 추가
			switch (searchCondition) {
			case 1: sql+=   "    where regexp_like( subject, ? , 'i') "; break;
			case 2: sql+=   "    where regexp_like( content, ? , 'i')  "; break;
			case 3: sql+=   "    where regexp_like( name, ? , 'i')  "; break;
			case 4: sql+=   "    where regexp_like( subject, ? , 'i')   or regexp_like( content, ? , 'i')  ";break;
			}
			//
			sql+=   "         order by seq desc                                    ";
			sql+=   "     ) t                                                      ";
			sql+=   " ) b                                                          ";
			sql+=   " where b.no between ? and ?                  ";	
			
			con = DBConn.getConnection();
			
			int start = (currentPage-1)*numberPerPage+1;
			int end   = currentPage*numberPerPage ;
			
			//searchWord = "%"+searchWord+"%";  
			
			pstmt = con.prepareStatement(sql);
				pstmt.setString(1, searchWord);
				if( searchCondition == 4 ) {
					pstmt.setString(2, searchWord);
					pstmt.setInt(3, start);  // 3
					pstmt.setInt(4, end);   // 4
				}else {
					pstmt.setInt(2, start);  // 3
					pstmt.setInt(3, end);   // 4
				}		
			
			rs =	pstmt.executeQuery();	
		
			if ( rs.next() ) {
				list = new ArrayList<>();  // 
				MyBoardDTO dto = null;
				do {
					dto = new MyBoardDTO();
					// seq, name, email, subject, cnt, regdate
						dto.setSeq( rs.getInt("seq") );
						dto.setName(rs.getString("name"));
						dto.setEmail(rs.getString("email"));
						
						String subject = rs.getString("subject") ;
						if( ! searchWord.equals("*") ) 
							subject = subject.replace(searchWord, "<span class='serachWord'>"+searchWord+"</span>");
						dto.setSubject(subject);
						
						dto.setCnt(rs.getInt("cnt"));
						dto.setRegdate(rs.getDate("regdate"));
					list.add(dto);  // 
				} while (rs.next());
			}
			request.setAttribute("list", list);  //
			rs.close();
			pstmt.close();
			
			// 페이징 처리 정보를 request.setAttribute();
			PageBlock   pageBlock = new PageBlock();
			  pageBlock.setCurrentPage(currentPage);
			  pageBlock.setNumberPerPage( numberPerPage );
			  pageBlock.setNumberOfpageBlocks( 10 );
			
			int numberOfPages = 0;
			sql = "select count(*)  numberOfPostings     " + 
		            "  , ceil( count(*)/? )   numberOfPages " + 
		            "  from tbl_myboard";
		    //  검색 쿼리 추가
			switch (searchCondition) {
				case 1: sql+=   "    where regexp_like( subject, ? , 'i') "; break;
				case 2: sql+=   "    where regexp_like( content, ? , 'i')  "; break;
				case 3: sql+=   "    where regexp_like( name, ? , 'i')  "; break;
				case 4: sql+=   "    where regexp_like( subject, ? , 'i')   or regexp_like( content, ? , 'i')  ";break;
			}
			//
			pstmt = con.prepareStatement(sql);		
			
			pstmt.setInt(1, numberPerPage ); 
			pstmt.setString(2, searchWord );
			if( searchCondition == 4)				pstmt.setString(3, searchWord);
			
			rs = pstmt.executeQuery();
			if( rs.next() ) {
				numberOfPages = rs.getInt(2);
			}
			pstmt.close();
			rs.close();
			pageBlock.setNumberOfPages( numberOfPages );
			// start , end , prev , next  
            int numberOfpageBlocks = pageBlock.getNumberOfpageBlocks();		
			int pageBlockStart = ( currentPage - 1) / numberOfpageBlocks * numberOfpageBlocks + 1;
			int pageBlockEnd = pageBlockStart + numberOfpageBlocks - 1;			
			pageBlockEnd = pageBlockEnd > numberOfPages ? numberOfPages : pageBlockEnd;
			pageBlock.setStart(pageBlockStart);
			pageBlock.setEnd(pageBlockEnd); 
			
			pageBlock.setPrev(pageBlock.getStart()==1 ? false : true); 
			pageBlock.setNext( pageBlockEnd== numberOfPages ? false : true);
			
			request.setAttribute("pageBlock", pageBlock);  //
			DBConn.close();
		} catch (Exception e) {  // 
			e.printStackTrace();
		} 
		
		

        //
		String path = "/days05/list.jsp";
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
