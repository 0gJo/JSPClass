package days04;

import java.io.IOException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.DBConn;

import days02.DeptDTO;
import days03.EmpDTO;

public class Test01_JobChangeServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	
	public String arrayJoin(String glue, String array[]) {
	    String result = "";
	    for (int i = 0; i < array.length; i++) {
	      result += array[i];
	      if (i < array.length - 1) result += glue;
	    }
	    return result; // "10,20"
	  }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		String uri = request.getRequestURI();
		String url = request.getRequestURL().toString();
		String path = request.getServletPath();
		
		System.out.println(url); http://localhost/jspPro/changegjob.do
		System.out.println(uri); /jspPro/changegjob.do
		System.out.println(path); /changegjob.do
		*/
		
		String empno = request.getParameter("empno");
		String job = request.getParameter("job");
		
		Connection con = null;
		Statement stmtEmp;
		
		try {
			// 1
			String sql = "update tbl_emp "
					+ " set job = '" + job + "'"
					+ " where empno = " + empno;	
			
			con = DBConn.getConnection();
			stmtEmp = con.createStatement();
			int result = stmtEmp.executeUpdate(sql);
			stmtEmp.close();
			
			if( result != 0 ){
				//  
			}			
			DBConn.close();
			
		} catch (Exception e) {  // 
			e.printStackTrace();
		} 
		
		 
		String params = ""; 
		String[] deptnos = request.getParameterValues("deptno");
		for (int i = 0; i < deptnos.length; i++) {
			params += "deptno="+ deptnos[i]+"&";
		}
		params = params.substring(0, params.length()-1); 
		String location = "employees.do?"+params; 		 
		response.sendRedirect(location);
		
		
		/*
		String path ="employees.do?"+params; 
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
		*/
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
