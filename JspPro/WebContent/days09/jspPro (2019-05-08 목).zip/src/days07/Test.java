package days07;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Test {
	
	public void test() {
		String fileName = "C:\\D\\Class\\JspClass\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\jspPro\\days05\\content.jsp";
		StringBuffer sb =  new StringBuffer();
		FileReader in = null;
		BufferedReader br = null;
		try {
			in = new FileReader(fileName);
			br = new BufferedReader(in);
			String line = null;
			
			while( (line = br.readLine() ) != null ) {
				sb.append( line );
			}
			
		} catch (FileNotFoundException e) { 
			e.printStackTrace();
		} catch (IOException e) { 
			e.printStackTrace();
		}
		
		String content = sb.toString();
		
		
		
		// 이 폴더에 있는 파일 읽어오기 -> select option
		/*
		String realPath = "C:\\D\\Class\\JspClass\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\jspPro\\days05";
		File dir = new File(realPath);
		// dir.isDirectory()
		File[] files = dir.listFiles();
		for (int i = 0; i < files.length; i++) {
			files[i].getName();
		}
		*/
		
		
	}

}
