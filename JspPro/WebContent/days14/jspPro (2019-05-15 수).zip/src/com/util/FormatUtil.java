package com.util;

import java.text.DecimalFormat;

public class FormatUtil {
	
	public static String number(long number, String pattern) {
		// 12345      #,##0       -> "12,345"
		// DecimalFormat  클래스
		DecimalFormat format = new DecimalFormat(pattern);
		return format.format(number);
	}

}
