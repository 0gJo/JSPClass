package board21.member.service;

//  p 596
public class DuplicatedIdException extends RuntimeException{

}
