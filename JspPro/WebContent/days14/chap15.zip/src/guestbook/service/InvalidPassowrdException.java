package guestbook.service;

public class InvalidPassowrdException extends ServiceException {

	public InvalidPassowrdException(String message) {
		super(message);
	}

}
